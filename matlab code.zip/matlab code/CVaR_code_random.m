%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orthogonal Portfolios to Assess Estimation Risk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Author: Luis Carlos Chavez-Bedoya
% Edited by: Francisco Rosales

clear all
clc

% load data

returns       = xlsread('KZDATA25.xlsx')/100
[temp1 temp2] = size(returns)
returns       = returns(2:temp1,2:temp2)

mu    = mean(returns)'
Sigma = cov(returns) 

% Basic parameters

n = size(Sigma);
n = n(1,1);
A = ones(1,n);
b = [1];

% Expressions used

S 	= Sigma;
Sinv    = inv(S);
C       = inv( A * Sinv * A');
R       = Sinv - Sinv * A' * C * A * Sinv;
wg      = inv(S) * A' * C * b;
mug     = wg' * mu;
s2g     = wg' * S* wg;
thetaH2 = mu' * R * mu;

% Simulation

t 	= 700;
gamma 	= 3;
nsim 	= 50000;

% Loop
ret_sim1 = zeros(nsim,3,5);
Rsim = zeros(t,n);

for i = 1:nsim
    
    % generate sample 
    Rsim        = mvnrnd(mu,S,t);
    mu_hat      = mean(Rsim)';
    S_hat       = ((t - 1) / t) * cov(Rsim);
    invS_hat    = inv(S_hat);
    Cp          = inv(A * invS_hat * A');
    R_hat       = invS_hat - invS_hat * A' * Cp * A * invS_hat;
    w_ghat      = inv(S_hat) * A' * Cp * b;
    mug_hat     = w_ghat' * mu_hat;
    s2g_hat     = w_ghat' * S_hat * w_ghat;
    thetaH2_hat = mu_hat' * R_hat * mu_hat;
    
    % coefficients of rules
        % kz 
        g_kz = (((t - n - 1) * (t - n - 4)) / (t * (t - 2))) * ...
               ((1 / gamma) * (mug_hat / s2g_hat));        	   
        h_kz = (((t - n - 1) * (t - n - 4))/(t * (t - 2))) * ... 
        	   ((thetaH2_hat) / (thetaH2_hat + (n / t)));
        % Q 
        g_q  = ((t - n - 1) / (t - 2)) * ((1 / gamma) * (mug_hat / s2g_hat));
        h_q  = (((t - n) * (t - n - 3)) / (t * (t - 2))) * ... 
        	   ((thetaH2_hat) / (thetaH2_hat + ((n - 1) / t)));
        % R 
        g_r  = 1;
        h_r  = h_q;
        % M 
        g_m  = g_kz;
        h_m  = h_q;
        % QS 
        g_qs = g_kz;
        h_qs = (((t - n) * (t - n - 5) * (t - n - 7)) / (t * t * (t - 2))) * ... 
        	   ((thetaH2_hat) / (thetaH2_hat + ((n - 1) / t)));
    
    % random funds to construct portfolio rules
        % fund hhat
        w_hhat = (1 / gamma) * R_hat * mu_hat;
    
    % components of portfolio rules
        
        % kz rule
        fund1_kz = g_kz * w_ghat;
        fund2_kz = h_kz * w_hhat;
        fund_kz  = fund1_kz + fund2_kz;

        % Q rule
        fund1_q = g_q * w_ghat;
        fund2_q = h_q * w_hhat;
        fund_q  = fund1_q + fund2_q;
        
        % R rule
        fund1_r = g_r * w_ghat;
        fund2_r = h_r * w_hhat;
        fund_r  = fund1_r + fund2_r;
        
        % M rule
        fund1_m = g_m * w_ghat;
        fund2_m = h_m * w_hhat;
        fund_m  = fund1_m + fund2_m;
        
        % QS rule
        fund1_qs = g_qs * w_ghat;
        fund2_qs = h_qs * w_hhat;
        fund_qs  = fund1_qs + fund2_qs;
    
    % out of sample return
        y = mvnrnd(mu,S,1);
        ret_sim1(i,:,1) = [y * fund1_kz  y * fund2_kz y * fund_kz];
        ret_sim1(i,:,2) = [y * fund1_q   y * fund2_q  y * fund_q];
        ret_sim1(i,:,3) = [y * fund1_r   y * fund2_r  y * fund_r];
        ret_sim1(i,:,4) = [y * fund1_m   y * fund2_m  y * fund_m];
        ret_sim1(i,:,5) = [y * fund1_qs  y * fund2_qs y * fund_qs];
end

% fixing the VaR level
VaRLevel = 0.95;

% kz
[VaRF1kz, ESF1kz] = hHistoricalVaRES(ret_sim1(:,1,1),VaRLevel);
[VaRF2kz, ESF2kz] = hHistoricalVaRES(ret_sim1(:,2,1),VaRLevel);
[VaRkz,   ESkz]   = hHistoricalVaRES(ret_sim1(:,3,1),VaRLevel);
E_kz    = mean(ret_sim1(:,:,1));
Sdev_kz = std(ret_sim1(:,:,1));
Var_kz  = Sdev_kz.^2;
SR_kz   = E_kz./Sdev_kz;

% q
[VaRF1q, ESF1q] = hHistoricalVaRES(ret_sim1(:,1,2),VaRLevel);
[VaRF2q, ESF2q] = hHistoricalVaRES(ret_sim1(:,2,2),VaRLevel);
[VaRq,   ESq]   = hHistoricalVaRES(ret_sim1(:,3,2),VaRLevel);
E_q    = mean(ret_sim1(:,:,2));
Sdev_q = std(ret_sim1(:,:,2));
Var_q  = Sdev_q.^2;
SR_q   = E_q./Sdev_q;

% r
[VaRF1r, ESF1r] = hHistoricalVaRES(ret_sim1(:,1,3),VaRLevel);
[VaRF2r, ESF2r] = hHistoricalVaRES(ret_sim1(:,2,3),VaRLevel);
[VaRr,   ESr]   = hHistoricalVaRES(ret_sim1(:,3,3),VaRLevel);
E_r    = mean(ret_sim1(:,:,3));
Sdev_r = std(ret_sim1(:,:,3));
Var_r  = Sdev_r.^2;
SR_r   = E_r./Sdev_r;

% m
[VaRF1m, ESF1m] = hHistoricalVaRES(ret_sim1(:,1,4),VaRLevel);
[VaRF2m, ESF2m] = hHistoricalVaRES(ret_sim1(:,2,4),VaRLevel);
[VaRm,   ESm]   = hHistoricalVaRES(ret_sim1(:,3,4),VaRLevel);
E_m    = mean(ret_sim1(:,:,4));
Sdev_m = std(ret_sim1(:,:,4));
Var_m  = Sdev_m.^2;
SR_m   = E_m./Sdev_m;

% qs
[VaRF1qs, ESF1qs] = hHistoricalVaRES(ret_sim1(:,1,5),VaRLevel);
[VaRF2qs, ESF2qs] = hHistoricalVaRES(ret_sim1(:,2,5),VaRLevel);
[VaRqs,   ESqs]   = hHistoricalVaRES(ret_sim1(:,3,5),VaRLevel);
E_qs    = mean(ret_sim1(:,:,5));
Sdev_qs = std(ret_sim1(:,:,5));
Var_qs  = Sdev_qs.^2;
SR_qs   = E_qs./Sdev_qs;

% results

% kz
ResultsSR_kz = [E_kz;
                Sdev_kz;
                SR_kz]';
corr_kz      = corr(ret_sim1(:,:,1));
Results_kz   = [VaRF1kz ESF1kz; 
                VaRF2kz ESF2kz; 
                (VaRkz - VaRF1kz - VaRF2kz) (ESkz - ESF1kz - ESF2kz); 
                VaRkz,ESkz];
VarRes_kz    = [Var_kz(1); 
                Var_kz(2);
                Var_kz(3) - Var_kz(1) - Var_kz(2);
                Var_kz(3)];
% q
ResultsSR_q = [E_q;
               Sdev_q;
               SR_q]';
corr_q      = corr(ret_sim1(:,:,2));
Results_q   = [VaRF1q ESF1q; 
               VaRF2q ESF2q; 
               (VaRq-VaRF1q-VaRF2q) (ESq-ESF1q-ESF2q);
               VaRq ESq];
VarRes_q    = [Var_q(1); 
               Var_q(2);
               Var_q(3) - Var_q(1) - Var_q(2); 
               Var_q(3)];

% r
ResultsSR_r = [E_r; 
               Sdev_r;
               SR_r]';
corr_r      = corr(ret_sim1(:,:,3));
Results_r   = [VaRF1r ESF1r; 
               VaRF2r,ESF2r; 
               (VaRr-VaRF1r-VaRF2r) (ESr-ESF1r-ESF2r); 
               VaRr,ESr];
VarRes_r    = [Var_r(1); 
               Var_r(2);
               Var_r(3) - Var_r(1) - Var_r(2); 
               Var_r(3)];

% m
ResultsSR_m = [E_m;
               Sdev_m;
               SR_m]';
corr_m      = corr(ret_sim1(:,:,4));
Results_m   = [VaRF1m ESF1m; 
               VaRF2m,ESF2m; 
               (VaRm-VaRF1m-VaRF2m) (ESm-ESF1m-ESF2m);
               VaRm,ESm];
VarRes_m    = [Var_m(1); 
               Var_m(2);
               Var_m(3) - Var_m(1) - Var_m(2); 
               Var_m(3)];

% qs
ResultsSR_qs = [E_qs;
                Sdev_qs;
                SR_qs]';
corr_qs      = corr(ret_sim1(:,:,5));
Results_qs   = [VaRF1qs ESF1qs; 
                VaRF2qs,ESF2qs; 
                (VaRqs-VaRF1qs-VaRF2qs) (ESqs-ESF1qs-ESF2qs);
                VaRqs,ESqs];
VarRes_qs    = [Var_qs(1); 
                Var_qs(2);
                Var_qs(3) - Var_qs(1) - Var_qs(2); 
                Var_qs(3)];

% Summarizing results as appear in paper
% VaR and ESR
Results_VaR = [Results_q(:,1) Results_m(:,1) Results_kz(:,1) Results_qs(:,1) Results_r(:,1)]
Results_ES  = [Results_q(:,2) Results_m(:,2) Results_kz(:,2) Results_qs(:,2) Results_r(:,2)]
Results_SR = [ResultsSR_q(:,3) ResultsSR_m(:,3) ResultsSR_kz(:,3) ...
              ResultsSR_qs(:,3) ResultsSR_r(:,3)]
Results_SR2 = [ResultsSR_q(:,3) ResultsSR_m(:,3) ResultsSR_kz(:,3) ...
               ResultsSR_qs(:,3) ResultsSR_r(:,3)].^2
Results_SR2 = [Results_SR2(1,:); Results_SR2(2,:); Results_SR2(3,:)-Results_SR2(1,:)-Results_SR2(2,:); ...
               Results_SR2(3,:)] 
Results_Variance = [VarRes_q VarRes_m VarRes_kz VarRes_qs VarRes_r];
Results_Variance = [Results_Variance; 100*Results_Variance(3,:)./Results_Variance(4,:)]
Results_corr     = [corr_q corr_m corr_kz corr_qs corr_r]


% Export data

%VaR
writematrix(Results_VaR,strcat('VaR_t',num2str(t),'.xlsx'), ...
            'Sheet',1,'Range','A1')

%ES
writematrix(Results_ES,strcat('ES_t',num2str(t),'.xlsx'), ...
            'Sheet',1,'Range','A1')

%SR2
writematrix(Results_SR2,strcat('SR2_t',num2str(t),'.xlsx'), ...
            'Sheet',1,'Range','A1')


